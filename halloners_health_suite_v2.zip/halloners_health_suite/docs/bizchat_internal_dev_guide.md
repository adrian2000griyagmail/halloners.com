# BizChat Internal Dev Guide

## Fokus
- Asistensi kerja tim dev + knowledge base internal.

## Rule
- Jangan keluarkan PII/PHI.
- Sertakan referensi file repo saat menjawab.

## Template Prompt
- Debug Flutter: paste log -> root cause + patch + test steps
- Review PR: paste diff -> security/performance/lint
- API client: openapi.yaml -> method client
