# Klasifikasi Data (Halloners Health)

## Level
- Public
- Internal
- Confidential
- Restricted (PII/PHI)

## Aturan
- Dilarang PII/PHI di log.
- Wajib audit akses PII/PHI.
