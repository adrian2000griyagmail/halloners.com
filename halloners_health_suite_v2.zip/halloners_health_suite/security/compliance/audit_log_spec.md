# Audit Log Spec
- wajib correlation-id
- payload jangan berisi PII mentah
