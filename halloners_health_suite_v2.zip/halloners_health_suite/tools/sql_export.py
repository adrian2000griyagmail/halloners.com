"""Export patients to JSON (demo).
Usage: python tools/sql_export.py
"""

import json
import os

try:
    import psycopg
except Exception:
    psycopg = None

DB = os.environ.get('DATABASE_URL', 'postgresql://halloners:halloners@localhost:5432/halloners_health')

if psycopg is None:
    raise SystemExit('psycopg not installed. Install: pip install psycopg[binary]')

with psycopg.connect(DB) as conn:
    rows = conn.execute('SELECT id, full_name, email FROM patients').fetchall()
    data = [{'id': str(r[0]), 'fullName': r[1], 'email': r[2]} for r in rows]
    print(json.dumps(data, indent=2))
