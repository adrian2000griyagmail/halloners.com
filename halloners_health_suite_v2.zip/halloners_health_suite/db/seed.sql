INSERT INTO clinicians (id, full_name, specialty) VALUES
 ('00000000-0000-0000-0000-000000000001', 'Dr. Sinta Laras', 'Umum'),
 ('00000000-0000-0000-0000-000000000002', 'Dr. Bagas Pradana', 'Penyakit Dalam')
ON CONFLICT DO NOTHING;

INSERT INTO patients (id, full_name, birth_date, gender, phone, email) VALUES
 ('10000000-0000-0000-0000-000000000001', 'Adrian Budiasna', '2000-01-01', 'M', '+62-812-0000-0000', 'adrian@example.com')
ON CONFLICT DO NOTHING;

INSERT INTO appointments (id, patient_id, clinician_id, scheduled_at, status, complaint) VALUES
 ('20000000-0000-0000-0000-000000000001',
  '10000000-0000-0000-0000-000000000001',
  '00000000-0000-0000-0000-000000000001',
  NOW() + INTERVAL '2 days',
  'scheduled',
  'Demam dan batuk 3 hari')
ON CONFLICT DO NOTHING;
