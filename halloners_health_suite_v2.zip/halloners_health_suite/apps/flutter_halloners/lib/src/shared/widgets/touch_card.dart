import 'package:flutter/material.dart';
import 'package:flutter_animate/flutter_animate.dart';

class TouchCard extends StatelessWidget {
  const TouchCard({super.key, required this.child, this.onTap});
  final Widget child;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    return Material(
      color: Colors.white,
      borderRadius: BorderRadius.circular(16),
      child: InkWell(
        borderRadius: BorderRadius.circular(16),
        onTap: onTap,
        splashColor: Theme.of(context).colorScheme.primary.withOpacity(0.15),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: child,
        ).animate().fadeIn(duration: 320.ms).slideY(begin: 0.08, end: 0.0),
      ),
    );
  }
}
