class Patient {
  const Patient({required this.id, required this.fullName, this.birthDate, this.gender, this.phone, this.email});
  final String id;
  final String fullName;
  final String? birthDate;
  final String? gender;
  final String? phone;
  final String? email;

  factory Patient.fromJson(Map<String, dynamic> json) => Patient(
        id: json['id'] as String,
        fullName: json['fullName'] as String,
        birthDate: json['birthDate'] as String?,
        gender: json['gender'] as String?,
        phone: json['phone'] as String?,
        email: json['email'] as String?,
      );
}
