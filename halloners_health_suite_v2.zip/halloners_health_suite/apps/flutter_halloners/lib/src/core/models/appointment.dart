class Appointment {
  const Appointment({
    required this.id,
    required this.patientId,
    required this.clinicianId,
    required this.scheduledAt,
    required this.status,
    this.complaint,
    this.notes,
  });
  final String id;
  final String patientId;
  final String clinicianId;
  final String scheduledAt;
  final String status;
  final String? complaint;
  final String? notes;

  factory Appointment.fromJson(Map<String, dynamic> json) => Appointment(
        id: json['id'] as String,
        patientId: json['patientId'] as String,
        clinicianId: json['clinicianId'] as String,
        scheduledAt: json['scheduledAt'] as String,
        status: json['status'] as String,
        complaint: json['complaint'] as String?,
        notes: json['notes'] as String?,
      );
}
