import 'package:dio/dio.dart';

class ApiClient {
  ApiClient({required String baseUrl})
      : _dio = Dio(BaseOptions(baseUrl: baseUrl, connectTimeout: const Duration(seconds: 10)));

  final Dio _dio;

  Future<Map<String, dynamic>> health() async {
    final r = await _dio.get('/health');
    return Map<String, dynamic>.from(r.data as Map);
  }

  Future<List<Map<String, dynamic>>> patients() async {
    final r = await _dio.get('/patients');
    return (r.data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }

  Future<List<Map<String, dynamic>>> appointments() async {
    final r = await _dio.get('/appointments');
    return (r.data as List).map((e) => Map<String, dynamic>.from(e as Map)).toList();
  }
}
