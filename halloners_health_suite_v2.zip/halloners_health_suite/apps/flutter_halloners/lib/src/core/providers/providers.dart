import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../api/api_client.dart';

const _base = String.fromEnvironment('HALLONERS_API', defaultValue: 'http://localhost:8080/api/v1');
final apiClientProvider = Provider<ApiClient>((ref) => ApiClient(baseUrl: _base));
