import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:google_fonts/google_fonts.dart';

import 'security/environment_banner.dart';
import 'features/dashboard/dashboard_page.dart';
import 'features/onboarding/onboarding_page.dart';
import 'features/patients/patients_page.dart';
import 'features/appointments/appointments_page.dart';

class HallonersApp extends StatelessWidget {
  const HallonersApp({super.key});

  @override
  Widget build(BuildContext context) {
    final router = GoRouter(routes: [
      GoRoute(path: '/', builder: (_, __) => const OnboardingPage()),
      GoRoute(path: '/dashboard', builder: (_, __) => const DashboardPage()),
      GoRoute(path: '/patients', builder: (_, __) => const PatientsPage()),
      GoRoute(path: '/appointments', builder: (_, __) => const AppointmentsPage()),
    ]);

    return EnvBanner(
      child: MaterialApp.router(
        title: 'Halloners Health',
        theme: ThemeData(
          useMaterial3: true,
          colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xFF1478C8)),
          textTheme: GoogleFonts.interTextTheme(),
        ),
        routerConfig: router,
        debugShowCheckedModeBanner: false,
      ),
    );
  }
}
