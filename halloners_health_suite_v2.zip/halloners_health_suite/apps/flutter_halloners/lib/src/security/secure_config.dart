class SecureConfig {
  static const bool isProd = bool.fromEnvironment('PROD', defaultValue: false);
  static const String apiBase = String.fromEnvironment(
    'HALLONERS_API',
    defaultValue: 'http://localhost:8080/api/v1',
  );
}
