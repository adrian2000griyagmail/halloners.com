import 'package:flutter/material.dart';
import 'secure_config.dart';

class EnvBanner extends StatelessWidget {
  const EnvBanner({super.key, required this.child});
  final Widget child;

  @override
  Widget build(BuildContext context) {
    if (SecureConfig.isProd) return child;
    return Banner(
      message: 'DEV',
      location: BannerLocation.topStart,
      color: Colors.orange,
      child: child,
    );
  }
}
