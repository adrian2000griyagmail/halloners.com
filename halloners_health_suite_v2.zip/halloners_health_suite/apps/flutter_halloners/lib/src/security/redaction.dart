String maskEmail(String? email) {
  if (email == null || !email.contains('@')) return '-';
  final parts = email.split('@');
  final name = parts.first;
  final masked = name.length <= 2 ? '${name[0]}***' : '${name.substring(0, 2)}***';
  return '$masked@${parts.last}';
}

String maskPhone(String? phone) {
  if (phone == null || phone.length < 6) return '-';
  return phone.substring(0, 3) + '****' + phone.substring(phone.length - 2);
}
