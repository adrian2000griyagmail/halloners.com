import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../../shared/widgets/touch_card.dart';

class DashboardPage extends StatelessWidget {
  const DashboardPage({super.key});

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard Halloners')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [cs.primary, cs.primaryContainer]),
              borderRadius: BorderRadius.circular(20),
            ),
            child: const Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Selamat datang 👋', style: TextStyle(color: Colors.white, fontWeight: FontWeight.w800, fontSize: 18)),
                SizedBox(height: 6),
                Text('Kelola pasien & jadwal klinik dengan mudah.', style: TextStyle(color: Colors.white70)),
              ],
            ),
          ),
          const SizedBox(height: 16),
          GridView.count(
            crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
            crossAxisSpacing: 12,
            mainAxisSpacing: 12,
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            children: [
              TouchCard(
                onTap: () => context.go('/patients'),
                child: const _Tile(icon: Icons.people_alt, title: 'Pasien', subtitle: 'Profil & data'),
              ),
              TouchCard(
                onTap: () => context.go('/appointments'),
                child: const _Tile(icon: Icons.calendar_month, title: 'Janji', subtitle: 'Jadwal & status'),
              ),
              TouchCard(
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Telemedicine (demo)'))),
                child: const _Tile(icon: Icons.video_call, title: 'Telemedicine', subtitle: 'Konsultasi'),
              ),
              TouchCard(
                onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Lab (demo)'))),
                child: const _Tile(icon: Icons.science, title: 'Lab', subtitle: 'Hasil pemeriksaan'),
              ),
            ],
          ),
          const SizedBox(height: 16),
          TouchCard(
            onTap: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Efek klik/touch aktif ✅'))),
            child: const Row(
              children: [
                Icon(Icons.touch_app),
                SizedBox(width: 12),
                Expanded(child: Text('Klik kartu ini untuk melihat ripple/splash (InkWell) + animasi.')),
              ],
            ),
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: () => ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Buat Janji Baru (demo)'))),
        icon: const Icon(Icons.add),
        label: const Text('Janji Baru'),
      ),
    );
  }
}

class _Tile extends StatelessWidget {
  const _Tile({required this.icon, required this.title, required this.subtitle});
  final IconData icon;
  final String title;
  final String subtitle;

  @override
  Widget build(BuildContext context) {
    return Row(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Container(
          width: 44,
          height: 44,
          decoration: BoxDecoration(
            color: Theme.of(context).colorScheme.primary.withOpacity(0.12),
            borderRadius: BorderRadius.circular(14),
          ),
          child: Icon(icon, color: Theme.of(context).colorScheme.primary),
        ),
        const SizedBox(width: 12),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
              const SizedBox(height: 4),
              Text(subtitle, style: TextStyle(color: Colors.black.withOpacity(0.6))),
            ],
          ),
        )
      ],
    );
  }
}
