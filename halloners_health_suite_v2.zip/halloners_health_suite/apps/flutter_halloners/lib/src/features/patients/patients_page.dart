import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/patient.dart';
import '../../core/providers/providers.dart';
import '../../shared/widgets/touch_card.dart';
import '../../security/redaction.dart';

final patientsProvider = FutureProvider<List<Patient>>((ref) async {
  final api = ref.watch(apiClientProvider);
  final list = await api.patients();
  return list.map(Patient.fromJson).toList();
});

class PatientsPage extends ConsumerWidget {
  const PatientsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncPatients = ref.watch(patientsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Pasien')),
      body: asyncPatients.when(
        data: (items) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemBuilder: (context, i) {
            final p = items[i];
            return TouchCard(
              onTap: () => ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text('Klik: ${p.fullName}'))),
              child: Row(
                children: [
                  CircleAvatar(child: Text(p.fullName.isNotEmpty ? p.fullName[0] : '?')),
                  const SizedBox(width: 12),
                  Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text(p.fullName, style: const TextStyle(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 4),
                    Text('${p.gender ?? '-'} • ${p.birthDate ?? '-'}', style: TextStyle(color: Colors.black.withOpacity(0.6))),
                    const SizedBox(height: 2),
                    Text('Email: ${maskEmail(p.email)}', style: TextStyle(color: Colors.black.withOpacity(0.55), fontSize: 12)),
                  ])),
                  const Icon(Icons.chevron_right)
                ],
              ),
            );
          },
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemCount: items.length,
        ),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        loading: () => const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
