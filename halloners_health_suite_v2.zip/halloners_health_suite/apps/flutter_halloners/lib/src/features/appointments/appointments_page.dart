import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../core/models/appointment.dart';
import '../../core/providers/providers.dart';
import '../../shared/widgets/touch_card.dart';

final appointmentsProvider = FutureProvider<List<Appointment>>((ref) async {
  final api = ref.watch(apiClientProvider);
  final list = await api.appointments();
  return list.map(Appointment.fromJson).toList();
});

class AppointmentsPage extends ConsumerWidget {
  const AppointmentsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final asyncItems = ref.watch(appointmentsProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('Janji Klinik')),
      body: asyncItems.when(
        data: (items) => ListView.separated(
          padding: const EdgeInsets.all(16),
          itemBuilder: (context, i) {
            final a = items[i];
            return TouchCard(
              onTap: () => showModalBottomSheet(
                context: context,
                showDragHandle: true,
                builder: (_) => Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.start, children: [
                    Text('Detail Janji', style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w800)),
                    const SizedBox(height: 10),
                    Text('Status: ${a.status}'),
                    Text('Jadwal: ${a.scheduledAt}'),
                    if (a.complaint != null) Text('Keluhan: ${a.complaint}'),
                    const SizedBox(height: 10),
                    FilledButton.icon(onPressed: () => Navigator.pop(context), icon: const Icon(Icons.check), label: const Text('Tutup')),
                  ]),
                ),
              ),
              child: Row(children: [
                const Icon(Icons.calendar_month),
                const SizedBox(width: 12),
                Expanded(child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(a.status, style: const TextStyle(fontWeight: FontWeight.w800)),
                  const SizedBox(height: 4),
                  Text(a.scheduledAt, style: TextStyle(color: Colors.black.withOpacity(0.6))),
                ])),
                const Icon(Icons.more_horiz)
              ]),
            );
          },
          separatorBuilder: (_, __) => const SizedBox(height: 12),
          itemCount: items.length,
        ),
        error: (e, _) => Center(child: Text('Gagal memuat: $e')),
        loading: () => const Center(child: CircularProgressIndicator()),
      ),
    );
  }
}
