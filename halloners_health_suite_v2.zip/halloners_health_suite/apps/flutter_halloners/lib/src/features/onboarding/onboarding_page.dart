import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';

class OnboardingPage extends StatefulWidget {
  const OnboardingPage({super.key});

  @override
  State<OnboardingPage> createState() => _OnboardingPageState();
}

class _OnboardingPageState extends State<OnboardingPage> {
  final _controller = PageController();
  int _index = 0;

  final _items = const [
    ('assets/images/onboarding_1.png', 'Perawatan Cepat', 'Cari layanan kesehatan yang tepat.'),
    ('assets/images/onboarding_2.png', 'Janji Klinik', 'Atur jadwal tanpa antri.'),
    ('assets/images/onboarding_3.png', 'Rekam Medis', 'Pantau ringkasan kesehatan.'),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            Expanded(
              child: PageView.builder(
                controller: _controller,
                onPageChanged: (i) => setState(() => _index = i),
                itemCount: _items.length,
                itemBuilder: (context, i) {
                  final (img, title, desc) = _items[i];
                  return Padding(
                    padding: const EdgeInsets.all(20),
                    child: Column(
                      children: [
                        const SizedBox(height: 20),
                        Image.asset(img, height: 240),
                        const SizedBox(height: 24),
                        Text(title, style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.w800)),
                        const SizedBox(height: 12),
                        Text(desc, textAlign: TextAlign.center),
                      ],
                    ),
                  );
                },
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 10, 20, 24),
              child: Row(
                children: [
                  Row(
                    children: List.generate(_items.length, (i) {
                      final active = i == _index;
                      return AnimatedContainer(
                        duration: const Duration(milliseconds: 240),
                        margin: const EdgeInsets.only(right: 8),
                        height: 8,
                        width: active ? 26 : 8,
                        decoration: BoxDecoration(
                          color: active ? Theme.of(context).colorScheme.primary : Colors.black12,
                          borderRadius: BorderRadius.circular(99),
                        ),
                      );
                    }),
                  ),
                  const Spacer(),
                  FilledButton(
                    onPressed: () {
                      if (_index < _items.length - 1) {
                        _controller.nextPage(duration: const Duration(milliseconds: 240), curve: Curves.easeOut);
                      } else {
                        context.go('/dashboard');
                      }
                    },
                    child: Text(_index < _items.length - 1 ? 'Lanjut' : 'Mulai'),
                  )
                ],
              ),
            )
          ],
        ),
      ),
    );
  }
}
