const BASE = 'http://localhost:8080/api/v1';

async function getJson(path){
  const r = await fetch(BASE + path);
  if(!r.ok) throw new Error('HTTP ' + r.status);
  return await r.json();
}

function itemTemplate(title, subtitle, tag){
  const div = document.createElement('div');
  div.className = 'item';
  div.innerHTML = `<div><b>${title}</b><div style="opacity:.7">${subtitle||''}</div></div><div class="tag">${tag||'info'}</div>`;
  div.addEventListener('click', ()=>{
    div.animate([{transform:'scale(1)'},{transform:'scale(0.98)'},{transform:'scale(1)'}],{duration:180});
  });
  return div;
}

document.getElementById('btnHealth').onclick = async ()=>{
  const out = document.getElementById('out');
  out.textContent = 'loading...';
  try{
    const data = await getJson('/health');
    out.textContent = JSON.stringify(data,null,2);
  }catch(e){
    out.textContent = String(e);
  }
}

document.getElementById('btnPatients').onclick = async ()=>{
  const list = document.getElementById('patientsList');
  list.innerHTML = '';
  const data = await getJson('/patients');
  data.forEach(p=> list.appendChild(itemTemplate(p.fullName, p.email || '-', p.gender || 'NA')));
}

document.getElementById('btnAppointments').onclick = async ()=>{
  const list = document.getElementById('appointmentsList');
  list.innerHTML = '';
  const data = await getJson('/appointments');
  data.forEach(a=> list.appendChild(itemTemplate(a.status, a.scheduledAt, 'appt')));
}
