# Runbook: API Outage
- cek docker
- cek logs
- rollback
