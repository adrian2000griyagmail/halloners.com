# Halloners Health Suite (Flutter Mobile + Web + Multi-Backend) - v2

Template proyek **halloners.com** (kesehatan) untuk internal **web developers** & **mobile developers**.

## Stack
- Flutter (Mobile + Web)
- Web Portal (HTML/CSS/JS)
- Backend: Node.js API Gateway + Python(FastAPI) + PHP adapter + Java(Spring Boot) + C++ stub
- Database: PostgreSQL + SQL schema/seed
- Kontrak: OpenAPI + JSON Schema

## Arsitektur & I/O

```
Flutter (tap/click/touch) ─┐
Web Portal (click)         ├──▶ API Gateway (Node) ───▶ Postgres (SQL)
                           │              │
                           │              ├──▶ FastAPI (Python) (triage demo)
                           │              └──▶ Spring Boot (Java) (health demo)
                           └── UI update ◀── JSON responses
```

### Input → Process → Output
- **Input**: gesture/klik UI, request HTTP/JSON, query params.
- **Process**: validasi, middleware security (headers/rate-limit/correlation/audit), query SQL.
- **Output**: JSON response, update state UI (Riverpod), efek InkWell + animasi.

## Cara Menjalankan

```bash
cd halloners_health_suite
docker compose up -d --build

cd apps/flutter_halloners
flutter pub get
flutter run -d chrome
```

Web portal:
```bash
cd apps/web_portal
python -m http.server 8088
```

## Tambahan Keamanan & Ops (v2)
- Folder baru: `security/`, `infra/`, `ops/`, `ci/`
- Node gateway: security headers + rate limit + correlation-id + audit log
- Flutter: environment banner (DEV) + util redaction
