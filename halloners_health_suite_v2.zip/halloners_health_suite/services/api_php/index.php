<?php
header('Content-Type: application/json');
$path = $_GET['path'] ?? 'health';
if ($path === 'health') { echo json_encode(['status'=>'ok','service'=>'php']); exit; }
if ($path === 'ping') { echo json_encode(['pong'=>true,'time'=>date('c')]); exit; }
http_response_code(404);
echo json_encode(['error'=>'not found']);
