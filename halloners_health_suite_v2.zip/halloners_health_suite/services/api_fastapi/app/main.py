from fastapi import FastAPI

app = FastAPI(title='Halloners FastAPI', version='1.0.0')

@app.get('/health')
def health():
    return {'status': 'ok', 'service': 'fastapi'}

@app.get('/triage')
def triage(symptoms: str = ''):
    s = symptoms.lower()
    level = 'low'
    if any(k in s for k in ['nyeri dada', 'sesak', 'pingsan']):
        level = 'high'
    elif any(k in s for k in ['demam', 'batuk', 'mual']):
        level = 'medium'
    return {'symptoms': symptoms, 'level': level, 'note': 'Demo saja, bukan diagnosis'}
