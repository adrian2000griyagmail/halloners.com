#include <iostream>
#include <string>
int main(int argc, char** argv){
  std::string device = argc>1? argv[1] : "demo-device";
  std::cout << "{"service":"cpp_device_bridge","device":"" << device << "","status":"ok"}";
  return 0;
}
