const buckets = new Map();

export function rateLimit({ rpm = 120 } = {}) {
  const windowMs = 60_000;
  return (req, res, next) => {
    const key = req.ip || 'unknown';
    const now = Date.now();
    const b = buckets.get(key) || { start: now, count: 0 };
    if (now - b.start > windowMs) { b.start = now; b.count = 0; }
    b.count++;
    buckets.set(key, b);

    if (b.count > rpm) return res.status(429).json({ error: 'rate_limited' });
    next();
  };
}
