import crypto from 'crypto';

export function correlationId(req, res, next) {
  const id = req.headers['x-correlation-id'] || crypto.randomUUID();
  req.correlationId = id;
  res.setHeader('x-correlation-id', id);
  next();
}

export function auditLog(pool, enabled = true) {
  return (req, res, next) => {
    if (!enabled) return next();
    res.on('finish', async () => {
      try {
        const actor = req.headers['x-actor'] || 'unknown';
        const action = `${req.method} ${req.path}`;
        await pool.query(
          'INSERT INTO audit_logs(actor, action, entity, entity_id, payload) VALUES($1,$2,$3,$4,$5)',
          [actor, action, 'http', req.correlationId || '-', { status: res.statusCode }]
        );
      } catch (_) {}
    });
    next();
  };
}
