import express from 'express';
import cors from 'cors';
import pg from 'pg';
import dotenv from 'dotenv';

import { securityHeaders } from './middleware/security_headers.js';
import { rateLimit } from './middleware/rate_limit.js';
import { correlationId, auditLog } from './middleware/audit_log.js';

dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());
app.use(correlationId);
app.use(securityHeaders);
app.use(rateLimit({ rpm: Number(process.env.RATE_LIMIT_RPM || 120) }));

const { Pool } = pg;
const pool = new Pool({ connectionString: process.env.DATABASE_URL });
app.use(auditLog(pool, String(process.env.AUDIT_LOG_ENABLED || 'true') === 'true'));

app.get('/api/v1/health', (req, res) => {
  res.json({ status: 'ok', gateway: 'node', time: new Date().toISOString(), correlationId: req.correlationId });
});

app.get('/api/v1/patients', async (req, res) => {
  const { rows } = await pool.query(
    'SELECT id, full_name as "fullName", birth_date as "birthDate", gender, phone, email FROM patients ORDER BY created_at DESC'
  );
  res.json(rows);
});

app.get('/api/v1/appointments', async (req, res) => {
  const { rows } = await pool.query(
    'SELECT id, patient_id as "patientId", clinician_id as "clinicianId", scheduled_at as "scheduledAt", status, complaint, notes FROM appointments ORDER BY scheduled_at DESC'
  );
  res.json(rows);
});

const port = process.env.PORT || 8080;
app.listen(port, () => console.log('Gateway listening on', port));
